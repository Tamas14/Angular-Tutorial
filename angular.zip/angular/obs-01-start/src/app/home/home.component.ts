import {Component, OnDestroy, OnInit} from '@angular/core';
import {interval, Observable, Subscription} from 'rxjs';
import {filter, map} from 'rxjs/operators';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit, OnDestroy {
  ob: Subscription;

  constructor() {
  }

  ngOnInit() {
    // this.ob = interval(1000).subscribe((count) => {
    //   console.log(count);
    // });
    const customIntervalOb = new Observable(subscriber => {
      let count = 0;
      setInterval(() => {
        subscriber.next(count++);
        if (count === 10)
          subscriber.complete();
      }, 1000)
    });

    this.ob = customIntervalOb.pipe(filter((data: number) => {
      return data % 2 === 0;
    }), map((data: number) => {
      return 'Round ' + (data + 1);
    })).subscribe((value) => {
      console.log(value);
    })
  }

  ngOnDestroy() {
    this.ob.unsubscribe();
  }

}
