import {Component, OnInit, EventEmitter, Output, OnDestroy, ViewChild} from '@angular/core';
import {Ingredient} from "../../shared/ingredient.model";
import {ShoppingListService} from "../shopping-list.service";
import {NgForm} from "@angular/forms";
import {Subscription} from "rxjs";

@Component({
  selector: 'app-shopping-edit',
  templateUrl: './shopping-edit.component.html',
  styleUrls: ['./shopping-edit.component.scss']
})
export class ShoppingEditComponent implements OnInit, OnDestroy {
  @ViewChild('f') slForm: NgForm;
  @Output() ingredientAdded = new EventEmitter<Ingredient>();
  subscription: Subscription;

  editMode = false;
  editIndex: number;
  editedItem: Ingredient;

  constructor(private shoppingListService: ShoppingListService) {
  }

  ngOnInit(): void {
    this.subscription = this.shoppingListService.startedEditing.subscribe((index: number) => {
      this.editMode = true;
      this.editIndex = index;
      this.editedItem = this.shoppingListService.getIngredient(index);
      setTimeout(() => {
        this.slForm.setValue({
          name: this.editedItem.name,
          amount: this.editedItem.amount
        })
      },1);
    })
  }

  onAddItem(form: NgForm) {
    const value = form.value
    const newIngredient = new Ingredient(value.name, parseInt(value.amount));
    if (this.editMode)
      this.shoppingListService.updateIngredient(this.editIndex, newIngredient);
    else
      this.shoppingListService.addIngredient(newIngredient);
    this.resetForm();
  }

  resetForm() {
    this.editMode = false;
    this.slForm.reset();
  }

  deleteIngredient() {
    this.shoppingListService.removeIngredient(this.editIndex);
    this.resetForm()
  }

  ngOnDestroy(): void {
    this.subscription.unsubscribe();
  }

}
